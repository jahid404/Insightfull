	<link rel="stylesheet" href="styles/footer.css">
	<footer>
		<div class="footer-logo" >
			<a href="index.php" >
				<img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhHhjKJQaEwO_9bmovqQJtH5Sux81lclFAgSMN50S9iBsAxTymruC-qImRoIE2iN4kgm2FkvyC8yj4UmDJqqxbJFtaIl3408em3y7JoCPGYos-5LMd1vSEZsIuw_aTA1Ny-ZPKH27hMKaEnPCMseDX2vjJ3fyhyD-OT9DdYmawEm9cql8_9uELlNIc-" alt="Insightful">
			</a>
		</div>
		<p>&copy; 2023 Insightful. All Rights Reserved.</p>
	</footer>