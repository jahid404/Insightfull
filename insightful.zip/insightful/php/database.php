<?php
// MySQL database information
$dbserver = "sql209.epizy.com";
$dbuser = "epiz_33948561";
$dbpass = "azPImnnTUN5N";
$dbname = "epiz_33948561_insightful";
?>